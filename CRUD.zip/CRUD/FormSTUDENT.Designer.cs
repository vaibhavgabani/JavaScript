﻿namespace CRUD
{
    partial class FormSTUDENT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            buttonUPDATE = new Button();
            label3 = new Label();
            buttonDELETE = new Button();
            buttonINSERT = new Button();
            label2 = new Label();
            label1 = new Label();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            textBox3 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(24, 549);
            button2.Name = "button2";
            button2.Size = new Size(589, 79);
            button2.TabIndex = 21;
            button2.Text = "SEARCH TAB";
            button2.UseVisualStyleBackColor = true;
            button2.Click += searchTabButton;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(325, 442);
            button1.Name = "button1";
            button1.Size = new Size(288, 79);
            button1.TabIndex = 20;
            button1.Text = "SEARCH";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // buttonUPDATE
            // 
            buttonUPDATE.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonUPDATE.Location = new Point(24, 442);
            buttonUPDATE.Name = "buttonUPDATE";
            buttonUPDATE.Size = new Size(288, 79);
            buttonUPDATE.TabIndex = 19;
            buttonUPDATE.Text = "UPDATE";
            buttonUPDATE.UseVisualStyleBackColor = true;
            buttonUPDATE.Click += buttonUPDATE_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(58, 29);
            label3.Name = "label3";
            label3.Size = new Size(59, 25);
            label3.TabIndex = 18;
            label3.Text = "label3";
            // 
            // buttonDELETE
            // 
            buttonDELETE.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonDELETE.Location = new Point(325, 336);
            buttonDELETE.Name = "buttonDELETE";
            buttonDELETE.Size = new Size(288, 79);
            buttonDELETE.TabIndex = 17;
            buttonDELETE.Text = "DELETE";
            buttonDELETE.UseVisualStyleBackColor = true;
            buttonDELETE.Click += buttonDELETE_Click;
            // 
            // buttonINSERT
            // 
            buttonINSERT.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonINSERT.Location = new Point(24, 336);
            buttonINSERT.Name = "buttonINSERT";
            buttonINSERT.Size = new Size(288, 79);
            buttonINSERT.TabIndex = 16;
            buttonINSERT.Text = "INSERT";
            buttonINSERT.UseVisualStyleBackColor = true;
            buttonINSERT.Click += buttonINSERT_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            label2.Location = new Point(58, 172);
            label2.Name = "label2";
            label2.Size = new Size(132, 48);
            label2.TabIndex = 15;
            label2.Text = "NAME";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            label1.Location = new Point(58, 96);
            label1.Name = "label1";
            label1.Size = new Size(240, 48);
            label1.TabIndex = 14;
            label1.Text = "STUDENT ID";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            textBox2.Location = new Point(325, 172);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(288, 55);
            textBox2.TabIndex = 13;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            textBox1.Location = new Point(325, 93);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(288, 55);
            textBox1.TabIndex = 12;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(654, 93);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(596, 535);
            dataGridView1.TabIndex = 11;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            label4.Location = new Point(58, 254);
            label4.Name = "label4";
            label4.Size = new Size(216, 48);
            label4.TabIndex = 23;
            label4.Text = "COURCE ID";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            textBox3.Location = new Point(325, 254);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(288, 55);
            textBox3.TabIndex = 22;
            // 
            // FormSTUDENT
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1296, 676);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(buttonUPDATE);
            Controls.Add(label3);
            Controls.Add(buttonDELETE);
            Controls.Add(buttonINSERT);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(dataGridView1);
            Name = "FormSTUDENT";
            Text = "FormSTUDENT";
            Load += FormSTUDENT_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private Button buttonUPDATE;
        private Label label3;
        private Button buttonDELETE;
        private Button buttonINSERT;
        private Label label2;
        private Label label1;
        private TextBox textBox2;
        private TextBox textBox1;
        private DataGridView dataGridView1;
        private Label label4;
        private TextBox textBox3;
    }
}