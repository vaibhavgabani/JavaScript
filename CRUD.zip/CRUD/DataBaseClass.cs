﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

namespace CRUD
{
    public class DataBaseClass
    {
        OracleConnection connection;
        OracleCommand command;
        OracleDataAdapter da;
        DataSet ds;

        public DataBaseClass(string stringConnection) 
        {
            connection = new OracleConnection(stringConnection);
        }

        public void IUD(string sqlQuary)
        {
            try
            {
                connection.Open();
                command = new OracleCommand(sqlQuary, connection);
                command.ExecuteNonQuery();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR : " + ex);
            }
        }

        public DataSet fillData(string sqlQuary) 
        {
            try
            {
                connection.Open();
                command = new OracleCommand(sqlQuary, connection);
                da = new OracleDataAdapter(command);
                ds = new DataSet();
                command.ExecuteNonQuery();
                da.Fill(ds);
                connection.Close();
                return ds;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR : " + ex);
            }
            return null;
        }
    }
}
