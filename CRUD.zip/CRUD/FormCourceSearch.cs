﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CRUD
{
    public partial class FormCourceSearch : Form
    {
        DataBaseClass dbc;
        public FormCourceSearch()
        {
            InitializeComponent();
            dbc = new DataBaseClass("User Id = ORACLE ; Password = ORACLE; Data Source = localhost:1521/XE");
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            string tmp = $"SELECT * FROM COURSE WHERE COURSE_ID LIKE '{textBoxSearch.Text}%' OR COURSE_NAME LIKE '{textBoxSearch.Text}%'";
            DataSet ds = new DataSet();
            ds = dbc.fillData(tmp);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
