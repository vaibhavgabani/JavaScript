﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CRUD
{
    public partial class FormStudentSearch : Form
    {
        
        DataBaseClass dbc;
        public FormStudentSearch()
        {
            InitializeComponent();
            dbc = new DataBaseClass("User Id = ORACLE ; Password = ORACLE; Data Source = localhost:1521/XE");
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            string tmp = $"SELECT * FROM STUDENT WHERE id LIKE '{textBoxSearch.Text}%' OR name LIKE '{textBoxSearch.Text}%' OR course_id LIKE '{textBoxSearch.Text}%'";
            label1.Text = tmp;
            DataSet ds = new DataSet();
            ds = dbc.fillData(tmp);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
