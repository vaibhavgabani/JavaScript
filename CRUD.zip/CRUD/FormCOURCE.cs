using System.Data;

namespace CRUD
{
    public partial class FormCOURCE : Form
    {
        DataBaseClass dbc;
        public FormCOURCE()
        {
            InitializeComponent();
            dbc = new DataBaseClass("User Id = ORACLE ; Password = ORACLE; Data Source = localhost:1521/XE");
        }

        private void FormINSERT_Load(object sender, EventArgs e)
        {
            loadData();
        }

        public void loadData()
        {
            DataSet ds = new DataSet();
            ds = dbc.fillData("SELECT * FROM course");
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void buttonINSERT_Click(object sender, EventArgs e)
        {
            string quary = "INSERT INTO course (course_id,course_name) VALUES (" + textBox1.Text + ",'" + textBox2.Text + "')";
            label3.Text = quary;
            dbc.IUD(quary);
            loadData();
        }

        private void buttonDELETE_Click(object sender, EventArgs e)
        {
            string quary = "DELETE FROM course WHERE course_id = " + textBox1.Text + "";
            label3.Text = quary;
            dbc.IUD(quary);
            loadData();
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.CurrentRow.Cells["COURSE_ID"].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells["COURSE_NAME"].Value.ToString();
        }

        private void buttonUPDATE_Click(object sender, EventArgs e)
        {
            string quary = "UPDATE course SET COURSE_NAME = '" + textBox2.Text + "' WHERE COURSE_ID = "+textBox1.Text+" ";
            label3.Text = quary;
            dbc.IUD(quary);
            loadData();
        }

        private void buttonSearchButton_Click(object sender, EventArgs e)
        {
            FormCourceSearch searchForm = new FormCourceSearch();
            searchForm.Show();
        }
    }
}
