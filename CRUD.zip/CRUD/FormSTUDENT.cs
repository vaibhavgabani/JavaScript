﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD
{
    public partial class FormSTUDENT : Form
    {
        DataBaseClass dbc;
        public FormSTUDENT()
        {
            InitializeComponent();
            dbc = new DataBaseClass("User Id = ORACLE ; Password = ORACLE; Data Source = localhost:1521/XE");
        }

        public void loadData()
        {
            DataSet ds = new DataSet();
            ds = dbc.fillData("SELECT * FROM student");
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void buttonINSERT_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO student (id, name, course_id) VALUES (" + textBox1.Text + ", '" + textBox2.Text + "', '" + textBox3.Text + "')";
            label3.Text = query;
            dbc.IUD(query);
            loadData();
        }

        private void buttonDELETE_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM student WHERE id = " + textBox1.Text;
            label3.Text = query;
            dbc.IUD(query);
            loadData();
        }

        private void buttonUPDATE_Click(object sender, EventArgs e)
        {
            string query = "UPDATE student SET name = '" + textBox2.Text + "', course_id = '" + textBox3.Text + "' WHERE id = " + textBox1.Text;
            label3.Text = query;
            dbc.IUD(query);
            loadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["id"].Value.ToString();
                textBox2.Text = row.Cells["name"].Value.ToString();
                textBox3.Text = row.Cells["course_id"].Value.ToString();
            }
        }

        private void FormSTUDENT_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void searchTabButton(object sender, EventArgs e)
        {
            FormStudentSearch fm = new FormStudentSearch();
            fm.Show();
        }
    }
}
