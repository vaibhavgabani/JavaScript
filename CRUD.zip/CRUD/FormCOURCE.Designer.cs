﻿namespace CRUD
{
    partial class FormCOURCE
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            buttonINSERT = new Button();
            buttonDELETE = new Button();
            label3 = new Label();
            buttonUPDATE = new Button();
            button1 = new Button();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(642, 73);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(596, 535);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            textBox1.Location = new Point(313, 73);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(288, 55);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            textBox2.Location = new Point(313, 189);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(288, 55);
            textBox2.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            label1.Location = new Point(46, 76);
            label1.Name = "label1";
            label1.Size = new Size(216, 48);
            label1.TabIndex = 3;
            label1.Text = "COURCE ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            label2.Location = new Point(46, 189);
            label2.Name = "label2";
            label2.Size = new Size(132, 48);
            label2.TabIndex = 4;
            label2.Text = "NAME";
            // 
            // buttonINSERT
            // 
            buttonINSERT.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonINSERT.Location = new Point(12, 316);
            buttonINSERT.Name = "buttonINSERT";
            buttonINSERT.Size = new Size(288, 79);
            buttonINSERT.TabIndex = 5;
            buttonINSERT.Text = "INSERT";
            buttonINSERT.UseVisualStyleBackColor = true;
            buttonINSERT.Click += buttonINSERT_Click;
            // 
            // buttonDELETE
            // 
            buttonDELETE.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonDELETE.Location = new Point(313, 316);
            buttonDELETE.Name = "buttonDELETE";
            buttonDELETE.Size = new Size(288, 79);
            buttonDELETE.TabIndex = 6;
            buttonDELETE.Text = "DELETE";
            buttonDELETE.UseVisualStyleBackColor = true;
            buttonDELETE.Click += buttonDELETE_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 9);
            label3.Name = "label3";
            label3.Size = new Size(59, 25);
            label3.TabIndex = 7;
            label3.Text = "label3";
            // 
            // buttonUPDATE
            // 
            buttonUPDATE.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonUPDATE.Location = new Point(12, 422);
            buttonUPDATE.Name = "buttonUPDATE";
            buttonUPDATE.Size = new Size(288, 79);
            buttonUPDATE.TabIndex = 8;
            buttonUPDATE.Text = "UPDATE";
            buttonUPDATE.UseVisualStyleBackColor = true;
            buttonUPDATE.Click += buttonUPDATE_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(313, 422);
            button1.Name = "button1";
            button1.Size = new Size(288, 79);
            button1.TabIndex = 9;
            button1.Text = "SEARCH";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(12, 529);
            button2.Name = "button2";
            button2.Size = new Size(589, 79);
            button2.TabIndex = 10;
            button2.Text = "SEARCH TAB";
            button2.UseVisualStyleBackColor = true;
            button2.Click += buttonSearchButton_Click;
            // 
            // FormCOURCE
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1267, 660);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(buttonUPDATE);
            Controls.Add(label3);
            Controls.Add(buttonDELETE);
            Controls.Add(buttonINSERT);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(dataGridView1);
            Name = "FormCOURCE";
            Text = "Form1";
            Load += FormINSERT_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private Button buttonINSERT;
        private Button buttonDELETE;
        private Label label3;
        private Button buttonUPDATE;
        private Button button1;
        private Button button2;
    }
}
