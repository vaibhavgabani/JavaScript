﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD
{
    public partial class FormMASTER : Form
    {
        private TabControl tabControl1;
        private TabPage tabPageCourse;
        private TabPage tabPageStudent;

        public FormMASTER()
        {
            InitializeComponent();
            InitializeTabControl();
            LoadFormsIntoTabs();
        }

        private void InitializeTabControl()
        {
            tabControl1 = new TabControl();
            tabPageCourse = new TabPage("Course");
            tabPageStudent = new TabPage("Student");

            tabControl1.Dock = DockStyle.Fill;
            tabControl1.TabPages.Add(tabPageCourse);
            tabControl1.TabPages.Add(tabPageStudent);

            this.Controls.Add(tabControl1);
        }

        private void LoadFormsIntoTabs()
        {
            // Embed FormCOURSE in the first tab
            FormCOURCE formCourse = new FormCOURCE();
            formCourse.TopLevel = false;
            formCourse.FormBorderStyle = FormBorderStyle.None;
            formCourse.Dock = DockStyle.Fill;
            tabPageCourse.Controls.Add(formCourse);
            formCourse.Show();

            // Embed FormSTUDENT in the second tab
            FormSTUDENT formStudent = new FormSTUDENT();
            formStudent.TopLevel = false;
            formStudent.FormBorderStyle = FormBorderStyle.None;
            formStudent.Dock = DockStyle.Fill;
            tabPageStudent.Controls.Add(formStudent);
            formStudent.Show();
        }
    }
}
